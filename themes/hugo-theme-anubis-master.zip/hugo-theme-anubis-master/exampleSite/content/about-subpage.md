---
title: "Subpage"
description: "Just a subpage of about"
date: "2019-02-28"
author: "Hugo Authors"
slug: /about/subpage
menu:
  about:
    identifier: about
    name: About
    title: About
    url: /about
    weight: 1
  subpage:
    identifier: subpage
    parent: about
    name: Subpage
    title: Subpage
    url: /about/subpage/
    weight: 10
---

Just a subpage of About.
